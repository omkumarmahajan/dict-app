import React from 'react';
import {
  View, 
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Platform,
  StatusBar,
  ImageBackground,
  Image,
  TextInput
} from 'react-native'
import { Header } from 'react-native-elements';

export default class App extends React.Component {
  render(){
    return( 
      <View style = {styles.container}>
      <Header
          backgroundColor="yellow"
          centerComponent={{
            text: 'Dictionary App',
            style: { color: 'black', fontWeight: 'bold' },
          }}></Header>

      <ImageBackground source ={require("./bg img.png")} style = {styles.backgroundImage}>
      <View style = {styles.titleBar}>
           < Text style={styles.titleText}>  Dictionary App </Text>
        
      </View>
    
  
</ImageBackground>
<TextInput
          style={styles.inputBox}
          onChangeText={(text) => {
            this.setState({
              text: text,
              isSearchedPressed: false,
              word: 'Loading....',
              lexicalCategory: '',
              examples: [],
              definition: '',
            });
          }}
        />

      </View>
    )
  }
}

const styles = StyleSheet.create({
    container: {
        flex: 1
    },
    droidSafeArea: {
        marginTop: Platform.OS === "android" ? StatusBar.currentHeight : 0
    },
    backgroundImage: {
        flex: 1,
        resizeMode: 'cover',
    },
    routeCard: {
        flex: 0.25,
        marginLeft: 50,
        marginRight: 50,
        marginTop: 50,
        borderRadius: 30,
        backgroundColor: 'white'
    },
    titleBar: {
        flex: 0.15,
        justifyContent: "center",
        alignItems: "center"
    },
    titleText: {
        fontSize: 40,
        fontWeight: "bold",
        color: "black",
        marginLeft : -10,
    },
    routeText: {
        fontSize: 35,
        fontWeight: "bold",
        color: "black",
        marginTop: 75,
        paddingLeft: 30
    },
    knowMore: {
        paddingLeft: 30,
        color: "red",
        fontSize: 15
    },
    bgDigit: {
        position: "absolute",
        color: "rgba(183, 183, 183, 0.5)",
        fontSize: 150,
        right: 20,
        bottom: -15,
        zIndex: -1
    },
    iconImage: {
        position: "absolute",
        height: 50,
        width: 50,
        resizeMode: "contain", 
        right: 50,
        top: 70
    },
    image:{
      
        height: 100,
        width: 100,
        
        right: 110,
        top: -2
    }
});